// TestTSP

#include <windows.h>
#include <tapi.h>
#include <tspi.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "resource.h"

static HANDLE ghInst;
static HTAPIDIALOGINSTANCE ghtDlgInst;
static HPROVIDER ghProvider;
static TUISPIDLLCALLBACK glpfnUIDLLCallback;
static ASYNC_COMPLETION glpfnCompletionProc;
static DRV_REQUESTID gdrvRequest;
static LINEEVENT glpfnEventProc;

BOOL WINAPI DllMain(HANDLE  hDLL, DWORD   dwReason, LPVOID  lpReserved)
{
	OutputDebugString("DllMain\r\n");
    if (dwReason ==  DLL_PROCESS_ATTACH)
        ghInst = hDLL;
    return TRUE;
}

LONG TSPIAPI TSPI_lineClose(HDRVLINE hdLine)
{
	OutputDebugString("TSPI_lineClose\r\n");
	glpfnEventProc = NULL;
	return 0;
}

LONG TSPIAPI TSPI_lineConditionalMediaDetection(HDRVLINE hdLine, DWORD dwMediaModes, LPLINECALLPARAMS const lpCallParams)
{
	OutputDebugString("TSPI_lineConditionalMediaDetection\r\n");
	return 0;
}

LONG TSPIAPI TSPI_lineGetAddressCaps(DWORD dwDeviceID, DWORD dwAddressID, 
									 DWORD dwTSPIVersion, DWORD dwExtVersion, LPLINEADDRESSCAPS lpAddressCaps)
{
	OutputDebugString("TSPI_lineGetAddressCaps\r\n");
    if (dwAddressID != 0)
        return LINEERR_INVALADDRESSID;
    lpAddressCaps->dwNeededSize = lpAddressCaps->dwUsedSize = sizeof(LINEADDRESSCAPS);
    lpAddressCaps->dwLineDeviceID = dwDeviceID;
    lpAddressCaps->dwAddressSharing		= LINEADDRESSSHARING_PRIVATE;
    lpAddressCaps->dwCallInfoStates     = LINECALLINFOSTATE_APPSPECIFIC;
    lpAddressCaps->dwCallerIDFlags      =
    lpAddressCaps->dwCalledIDFlags      =
    lpAddressCaps->dwRedirectionIDFlags =
    lpAddressCaps->dwRedirectingIDFlags = LINECALLPARTYID_UNAVAIL;
    lpAddressCaps->dwCallStates         = LINECALLSTATE_IDLE | LINECALLSTATE_UNKNOWN;
    lpAddressCaps->dwDialToneModes      = LINEDIALTONEMODE_UNAVAIL;
    lpAddressCaps->dwBusyModes          = LINEBUSYMODE_UNAVAIL;
    lpAddressCaps->dwSpecialInfo        = LINESPECIALINFO_UNAVAIL;
    lpAddressCaps->dwDisconnectModes    = LINEDISCONNECTMODE_UNAVAIL;
    lpAddressCaps->dwMaxNumActiveCalls  = 1;
    lpAddressCaps->dwAddrCapFlags       = LINEADDRCAPFLAGS_DIALED;
    lpAddressCaps->dwCallFeatures       = LINECALLFEATURE_DROP;
    lpAddressCaps->dwAddressFeatures    = LINEADDRFEATURE_MAKECALL;

    return 0;
}

LONG TSPIAPI TSPI_lineGetAddressStatus(HDRVLINE hdLine, DWORD dwAddressID, LPLINEADDRESSSTATUS lpAddressStatus)
{
	OutputDebugString("TSPI_lineGetAddressStatus\r\n");
    lpAddressStatus->dwNeededSize = lpAddressStatus->dwUsedSize   = sizeof(LINEADDRESSSTATUS);
    lpAddressStatus->dwNumActiveCalls  = 0;
    lpAddressStatus->dwAddressFeatures = 0;
    return 0;
}

LONG TSPIAPI TSPI_lineGetDevCaps(DWORD dwDeviceID, DWORD dwTSPIVersion, DWORD dwExtVersion, LPLINEDEVCAPS lpLineDevCaps)
{
    static WCHAR szProviderInfo[] = L"Test TSP";
    static WCHAR szLineInfo[] = L"Test Line #1";

	OutputDebugString("TSPI_lineGetDevCaps\r\n");

    lpLineDevCaps->dwNeededSize = sizeof (LINEDEVCAPS) + 
		(lstrlenW(szProviderInfo)+1) * sizeof(WCHAR) +
        (lstrlenW(szLineInfo)+1) * sizeof (WCHAR);

    if (lpLineDevCaps->dwTotalSize >= lpLineDevCaps->dwNeededSize)
    {
        lpLineDevCaps->dwUsedSize = lpLineDevCaps->dwNeededSize;
        lpLineDevCaps->dwProviderInfoSize   = (lstrlenW(szProviderInfo)+1) * sizeof(WCHAR);
        lpLineDevCaps->dwProviderInfoOffset = sizeof(LINEDEVCAPS);
        CopyMemory((void *)(lpLineDevCaps + 1), szProviderInfo, lpLineDevCaps->dwProviderInfoSize);
        lpLineDevCaps->dwLineNameSize   = (lstrlenW(szLineInfo)+1) * sizeof(WCHAR);
        lpLineDevCaps->dwLineNameOffset = sizeof(LINEDEVCAPS) + lpLineDevCaps->dwProviderInfoSize;
    }
    else
        lpLineDevCaps->dwUsedSize = sizeof(LINEDEVCAPS);

    lpLineDevCaps->dwStringFormat = STRINGFORMAT_ASCII;
    lpLineDevCaps->dwAddressModes = LINEADDRESSMODE_ADDRESSID;
    lpLineDevCaps->dwNumAddresses = 1;
    lpLineDevCaps->dwBearerModes  = LINEBEARERMODE_VOICE;
    lpLineDevCaps->dwMaxRate      = 0;
    lpLineDevCaps->dwMediaModes   = LINEMEDIAMODE_INTERACTIVEVOICE;
    lpLineDevCaps->dwDevCapFlags  = LINEDEVCAPFLAGS_CLOSEDROP;
    lpLineDevCaps->dwMaxNumActiveCalls = 1;
    lpLineDevCaps->dwRingModes    = 1;
    lpLineDevCaps->dwLineFeatures = LINEFEATURE_MAKECALL;
    return 0;
}

LONG TSPIAPI TSPI_lineGetLineDevStatus(HDRVLINE hdLine, LPLINEDEVSTATUS lpLineDevStatus)
{
	OutputDebugString("TSPI_lineGetDevStatus\r\n");
    lpLineDevStatus->dwUsedSize =
    lpLineDevStatus->dwNeededSize = sizeof (LINEDEVSTATUS);
    lpLineDevStatus->dwNumActiveCalls = 0;
    lpLineDevStatus->dwDevStatusFlags = LINEDEVSTATUSFLAGS_CONNECTED | LINEDEVSTATUSFLAGS_INSERVICE;
    return 0;
}

LONG TSPIAPI TSPI_lineGetNumAddressIDs(HDRVLINE hdLine, LPDWORD lpdwNumAddressIDs)
{
	OutputDebugString("TSPI_lineGetNumAddressIDs\r\n");
    *lpdwNumAddressIDs = 1;
    return 0;
}

LONG TSPIAPI TSPI_lineMakeCall(DRV_REQUESTID dwRequestID, HDRVLINE hdLine, HTAPICALL htCall, LPHDRVCALL lphdCall, LPCWSTR lpszDestAddress, DWORD dwCountryCode, LPLINECALLPARAMS const lpCallParams)
{
	static TUISPICREATEDIALOGINSTANCEPARAMS Params;
	
	OutputDebugString("TSPI_lineMakeCall\r\n");

	if (gdrvRequest)
		return LINEERR_OPERATIONUNAVAIL;

	gdrvRequest = dwRequestID;
	*lphdCall = (HDRVCALL) 0x76543210;

	Params.dwRequestID = dwRequestID;
	Params.lpszUIDLLName = L"TSPTEST.TSP";
	Params.hdDlgInst = (HDRVDIALOGINSTANCE) 0x6543210;
	Params.htDlgInst = NULL;
	Params.lpParams = NULL;
	Params.dwSize = 0;
	glpfnEventProc((HTAPILINE)ghProvider, 0, LINE_CREATEDIALOGINSTANCE, (DWORD)&Params, 0, 0);

	return dwRequestID;
}

LONG TSPIAPI TSPI_lineNegotiateTSPIVersion(DWORD dwDeviceID, DWORD dwLowVersion, DWORD dwHighVersion, LPDWORD lpdwTSPIVersion)
{
	OutputDebugString("TSPI_lineNegotiateTSPIVersion\r\n");
    *lpdwTSPIVersion = 0x00020000;
    return 0;
}

LONG TSPIAPI TSPI_lineOpen(DWORD dwDeviceID, HTAPILINE htLine, LPHDRVLINE  lphdLine, DWORD dwTSPIVersion, LINEEVENT lpfnEventProc)
{
	OutputDebugString("TSPI_lineOpen\r\n");
	*lphdLine = (HDRVLINE) htLine;
	glpfnEventProc = lpfnEventProc;
    return 0;
}

LONG TSPIAPI TSPI_lineSetDefaultMediaDetection(HDRVLINE hdLine, DWORD dwMediaModes)
{
	OutputDebugString("TSPI_lineSetDefaultMediaDetection\r\n");
    return 0;
}

LONG TSPIAPI TSPI_providerConfig(HWND hwndOwner, DWORD dwPermanentProviderID)
{
    return 0;
}

LONG TSPIAPI TSPI_providerFreeDialogInstance(HDRVDIALOGINSTANCE  hdDlgInst)
{
	OutputDebugString("TSPI_providerFreeDialogInstance\r\n");
	return 0;
}

LONG TSPIAPI TSPI_providerGenericDialogData(DWORD_PTR dwObjectID, DWORD dwObjectType, LPVOID lpParams, DWORD dwSize)
{
	LPCSTR lpByte = (LPCSTR) lpParams;

	OutputDebugString("TSPI_providerGenericDialogData\r\n");

	if (!glpfnCompletionProc || !gdrvRequest)
		return LINEERR_OPERATIONUNAVAIL;

	if (dwSize == 1 && *lpByte == 'A')
	{
		glpfnCompletionProc(gdrvRequest, LINEERR_OPERATIONFAILED);
		gdrvRequest = 0;
	}
	
	if (lpByte && dwSize > 0)
	{
		DWORD dwCount = 0, dwLine = 0;
		while (dwCount < dwSize)
		{
			int i;
			char b[17], szBuff[20];
			wsprintf(szBuff, "%0.8lX   ", dwLine);
			OutputDebugString(szBuff);

			// Add the digits
			for (i = 0; i < 16; i++)
			{
				if (dwSize-dwCount > 0)
				{
					b[i] = *lpByte++;
					dwCount++;
					wsprintf(szBuff, "%0.2X ", (int)b[i]&0xff);
					OutputDebugString(szBuff);
				}
				else
				{
					OutputDebugString("   ");
					b[i] = 0;
				}

				// Change to a '.' if it is not printable
			    if (!isprint(b[i]))
			        b[i] = '.';
			}

			// Add the ascii portion
			b[16] = '\0';
			OutputDebugString("   ");
			OutputDebugString(b);
			OutputDebugString("\r\n");
			dwLine = dwCount;
		}
	}
	
    return 0;
}

LONG TSPIAPI TSPI_providerInit(DWORD dwTSPIVersion, DWORD dwPermanentProviderID, DWORD dwLineDeviceIDBase,
							   DWORD dwPhoneDeviceIDBase, DWORD dwNumLines, DWORD dwNumPhones,
							   ASYNC_COMPLETION lpfnCompletionProc, LPDWORD lpdwTSPIOptions)
{
	OutputDebugString("TSPI_providerInit\r\n");
    *lpdwTSPIOptions = 0;
	glpfnCompletionProc = lpfnCompletionProc;
    return 0;
}

LONG TSPIAPI TSPI_providerInstall(HWND hwndOwner, DWORD dwPermanentProviderID)
{
    return 0;
}

LONG TSPIAPI TSPI_providerRemove(HWND hwndOwner, DWORD dwPermanentProviderID)
{
    return 0;
}

LONG TSPIAPI TSPI_providerShutdown(DWORD dwTSPIVersion, DWORD dwPermanentProviderID)
{
	OutputDebugString("TSPI_providerShutdown\r\n");
    return 0;
}

LONG TSPIAPI TSPI_providerEnumDevices(DWORD dwPermanentProviderID, LPDWORD lpdwNumLines,
									  LPDWORD lpdwNumPhones, HPROVIDER hProvider, LINEEVENT lpfnLineCreateProc,
									  PHONEEVENT lpfnPhoneCreateProc)
{
	OutputDebugString("TSPI_providerEnumDevices\r\n");
	ghProvider = hProvider;
	*lpdwNumLines  = 1;
	*lpdwNumPhones = 0;
	return 0;
}

LONG TSPIAPI TSPI_providerUIIdentify(LPWSTR lpszUIDLLName)
{
	WCHAR* pszName = L"tsptest.tsp";
	OutputDebugString("TSPI_providerUIIdentify\r\n");
    CopyMemory(lpszUIDLLName, pszName, (lstrlenW(pszName)+1) * sizeof(WCHAR));
    return 0;
}

LONG TSPIAPI TUISPI_providerConfig(TUISPIDLLCALLBACK lpfnUIDLLCallback, HWND hwndOwner, DWORD dwPermanentProviderID)
{
    return 0;
}

LONG TSPIAPI TUISPI_providerRemove(TUISPIDLLCALLBACK lpfnUIDLLCallback, HWND hwndOwner, DWORD dwPermanentProviderID)
{
	return 0;
}

LONG TSPIAPI TUISPI_providerInstall(TUISPIDLLCALLBACK lpfnUIDLLCallback, HWND hwndOwner, DWORD dwPermanentProviderID)
{
	MessageBox(hwndOwner, "Provider installed", "Test TAPI provider", MB_OK);
    return 0;
}

LRESULT WINAPI TestDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
			{
				SendDlgItemMessage(hwnd, IDC_SIZE2, EM_LIMITTEXT, (WPARAM)5, 0);
				return TRUE;
			}
			break;

		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				case IDC_SEND:
					{
						BOOL fTranslated;
						int iSize = GetDlgItemInt(hwnd, IDC_SIZE2, &fTranslated, FALSE);
						if (iSize > 0)
						{
							char *p, *pBuff;
							p = pBuff = malloc(iSize);
							if (pBuff != NULL && glpfnUIDLLCallback)
							{
								int i;
								for (i = 0; i < iSize; i++, p++)
									*p = '0' + (i%9);
								glpfnUIDLLCallback((DWORD)ghtDlgInst, TUISPIDLL_OBJECT_DIALOGINSTANCE, pBuff, iSize);
								free(pBuff);
							}
						}
					}
					break;
				case IDOK:
				case IDCANCEL:
					EndDialog(hwnd, IDOK);
					break;
			}
			return TRUE;
		}
	}
	return FALSE;
}

LONG TSPIAPI TUISPI_providerGenericDialog(TUISPIDLLCALLBACK lpfnUIDLLCallback, HTAPIDIALOGINSTANCE htDlgInst,
										  LPVOID lpParams, DWORD dwSize, HANDLE hEvent)
{
	SetEvent(hEvent);
	ghtDlgInst = htDlgInst;
	glpfnUIDLLCallback = lpfnUIDLLCallback;
	DialogBox(ghInst, MAKEINTRESOURCE(IDD_DIALOG1), NULL, TestDialogProc);
	glpfnUIDLLCallback((DWORD)ghtDlgInst, TUISPIDLL_OBJECT_DIALOGINSTANCE, "A", 1);
	return 0;
}


